@extends('layouts.vertical', ['title' => 'Master System Control'])

@section('css')
<link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
<style>
    .tab-pane {
        padding-top: 1.5rem;
    }
    .metric-card {
        border-radius: 10px;
        transition: all 0.3s ease;
        border: none;
        box-shadow: 0 2px 6px rgba(0,0,0,0.04);
    }
    .metric-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 6px 16px rgba(0,0,0,0.1);
    }

    /* Workflow Pipeline */
    .workflow-container {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0;
        overflow-x: auto;
        padding: 2rem 1rem;
        background: linear-gradient(135deg, #f8f9fc 0%, #eef1f7 100%);
        border-radius: 10px;
        margin-bottom: 2rem;
    }
    .workflow-step {
        text-align: center;
        position: relative;
        flex: 0 0 auto;
        min-width: 130px;
        padding: 0 10px;
    }
    .workflow-circle {
        width: 64px;
        height: 64px;
        border-radius: 50%;
        background: #fff;
        border: 3px solid #dee2e6;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        font-size: 1.3rem;
        margin-bottom: 0.5rem;
        transition: all 0.3s ease;
        position: relative;
        z-index: 2;
        box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    }
    .workflow-arrow {
        display: inline-flex;
        align-items: center;
        color: #adb5bd;
        font-size: 1.5rem;
        margin: 0 -5px;
        padding-top: 0;
        position: relative;
        top: -18px;
    }
    .workflow-arrow i { font-size: 24px; }
    .workflow-step.active .workflow-circle {
        border-color: #6c5ffc;
        background: linear-gradient(135deg, #f0eeff, #e8e5ff);
        color: #6c5ffc;
    }
    .workflow-step.completed .workflow-circle {
        border-color: #10b981;
        background: linear-gradient(135deg, #e6f7f0, #d4f0e4);
        color: #10b981;
    }
    .workflow-step.warning .workflow-circle {
        border-color: #f59e0b;
        background: linear-gradient(135deg, #fef3c7, #fde68a);
        color: #f59e0b;
    }
    .workflow-step.suspended .workflow-circle {
        border-color: #ef4444;
        background: linear-gradient(135deg, #fee2e2, #fecaca);
        color: #ef4444;
    }

    /* Tab Navigation */
    .nav-tabs-custom .nav-link {
        border: none;
        color: #6c757d;
        font-weight: 500;
        padding: 12px 16px;
        border-radius: 0;
        border-bottom: 3px solid transparent;
        font-size: 13px;
        transition: all 0.2s ease;
    }
        .nav-tabs-custom .nav-link:hover {
        color: #004392;
        background: rgba(0, 67, 146, 0.1);
        transition: background 0.2s ease;
    }
    .nav-tabs-custom .nav-link.active {
        color: #004392 !important;
        border-bottom-color: #004392;
        background: rgba(0, 67, 146, 0.06);
        font-weight: 600;
    }
    .nav-tabs-custom {
        border-bottom: 2px solid #e9ecef;
        flex-wrap: nowrap;
        overflow-x: auto;
        overflow-y: hidden;
    }
    .nav-tabs-custom::-webkit-scrollbar {
        height: 3px;
    }
    .nav-tabs-custom::-webkit-scrollbar-thumb {
        background: #004392;
        border-radius: 3px;
    }
    .form-switch .form-check-input {
        width: 2.5em;
        height: 1.25em;
        cursor: pointer;
    }

    /* Stat cards for tabs */
    .stat-card-sm {
        border-radius: 10px;
        padding: 18px 16px;
        text-align: center;
        transition: all 0.3s ease;
        border: none;
    }
    .stat-card-sm:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }
    .stat-card-sm h3 {
        margin-bottom: 2px;
        font-weight: 700;
    }
    .stat-card-sm .stat-icon {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 1.2rem;
        margin-bottom: 8px;
    }

    /* Sub-pills */
    .nav-pills-custom .nav-link {
        border-radius: 6px;
        padding: 6px 16px;
        font-size: 13px;
        font-weight: 500;
        color: #495057;
        background: #f1f3f5;
        margin-right: 6px;
        transition: all 0.2s ease;
    }
    .nav-pills-custom .nav-link.active {
        background: #6c5ffc;
        color: #fff;
    }

    /* Priority badge */
    .priority-badge {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 14px;
        color: #fff;
    }

    /* Table improvements */
    .table th {
        font-weight: 600;
        letter-spacing: 0.5px;
    }
    .table td {
        vertical-align: middle;
    }
    .btn-icon {
        width: 32px;
        height: 32px;
        padding: 0;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 6px;
    }

    /* Info box */
    .info-box {
        background: linear-gradient(135deg, #e8f4fd 0%, #dbeafe 100%);
        border-left: 4px solid #3b82f6;
        border-radius: 8px;
        padding: 16px 20px;
    }

    /* Example box */
    .example-box {
        background: linear-gradient(135deg, #fef9e7 0%, #fef3c7 100%);
        border-left: 4px solid #f59e0b;
        border-radius: 8px;
        padding: 16px 20px;
    }
</style>
@endsection

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Master System Control</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Master System Control</a></li>
                        <li class="breadcrumb-item active" id="breadcrumb-active">Overview</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body p-0">
            <!-- Tabs Navigation -->
            <ul class="nav nav-tabs nav-tabs-custom nav-justified" id="masterSettingsTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="overview-tab" data-bs-toggle="tab" data-bs-target="#overview" type="button" role="tab" aria-controls="overview" aria-selected="true">
                        <i class="bx bx-home-alt fs-5 d-block text-center mb-1"></i> Overview
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="rule-priority-tab" data-bs-toggle="tab" data-bs-target="#rule-priority" type="button" role="tab">
                        <i class="bx bx-sort-up fs-5 d-block text-center mb-1"></i> 2. Rule Priority
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="validation-rules-tab" data-bs-toggle="tab" data-bs-target="#validation-rules" type="button" role="tab">
                        <i class="bx bx-check-shield fs-5 d-block text-center mb-1"></i> 3. Validation Rules
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="workflow-rules-tab" data-bs-toggle="tab" data-bs-target="#workflow-rules" type="button" role="tab">
                        <i class="bx bx-git-branch fs-5 d-block text-center mb-1"></i> 4. Workflow Rules
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="automation-rules-tab" data-bs-toggle="tab" data-bs-target="#automation-rules" type="button" role="tab">
                        <i class="bx bx-network-chart fs-5 d-block text-center mb-1"></i> 5. Automation Rules
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="role-management-tab" data-bs-toggle="tab" data-bs-target="#role-management" type="button" role="tab">
                        <i class="bx bx-user-pin fs-5 d-block text-center mb-1"></i> 6. Admin Role
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="compliance-tab" data-bs-toggle="tab" data-bs-target="#compliance" type="button" role="tab">
                        <i class="bx bx-shield-quarter fs-5 d-block text-center mb-1"></i> 7. Compliance
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="notification-engine-tab" data-bs-toggle="tab" data-bs-target="#notification-engine" type="button" role="tab">
                        <i class="bx bx-bell fs-5 d-block text-center mb-1"></i> 8. Notifications
                    </button>
                </li>
            </ul>

            <!-- Tabs Content -->
            <div class="tab-content p-4" id="masterSettingsTabContent">

                <!-- ==================== 1. OVERVIEW TAB ==================== -->
                <div class="tab-pane fade show active" id="overview" role="tabpanel" aria-labelledby="overview-tab">
                    <!-- Metric Cards Row -->
                    <div class="row g-3">
                        <div class="col-xl-2 col-md-4 col-sm-6">
                            <div class="card metric-card border-start border-4 border-primary">
                                <div class="card-body text-center py-3">
                                    <h6 class="text-muted text-uppercase mb-2 fs-11">Rule Engine</h6>
                                    <h2 class="mb-1 text-primary fw-bold" id="metric-rules-count">0</h2>
                                    <span class="badge bg-primary bg-opacity-10 text-primary fs-11" id="metric-rules-badge">0 Active Rules</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-2 col-md-4 col-sm-6">
                            <div class="card metric-card border-start border-4 border-info">
                                <div class="card-body text-center py-3">
                                    <h6 class="text-muted text-uppercase mb-2 fs-11">Admin Role</h6>
                                    <h2 class="mb-1 text-info fw-bold" id="metric-roles-count">0</h2>
                                    <span class="badge bg-info bg-opacity-10 text-info fs-11">Roles</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-2 col-md-4 col-sm-6">
                            <div class="card metric-card border-start border-4 border-warning">
                                <div class="card-body text-center py-3">
                                    <h6 class="text-muted text-uppercase mb-2 fs-11">Compliance</h6>
                                    <h2 class="mb-1 text-warning fw-bold" id="metric-compliance-count">0</h2>
                                    <span class="badge bg-warning bg-opacity-10 text-warning fs-11">Policies</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-2 col-md-4 col-sm-6">
                            <div class="card metric-card border-start border-4 border-danger">
                                <div class="card-body text-center py-3">
                                    <h6 class="text-muted text-uppercase mb-2 fs-11">Integrations</h6>
                                    <h2 class="mb-1 text-danger fw-bold" id="metric-notifications-count">0</h2>
                                    <span class="badge bg-danger bg-opacity-10 text-danger fs-11" id="metric-notifications-badge">Active</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-2 col-md-4 col-sm-6">
                            <div class="card metric-card border-0 bg-success text-white">
                                <div class="card-body text-center py-3">
                                    <h6 class="text-white text-uppercase mb-2 fs-11">System Health</h6>
                                    <h2 class="mb-1 text-white fw-bold">Good</h2>
                                    <span class="badge bg-white text-success fs-11">All Systems Operational</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- System Control Activity -->
                    <div class="card mt-3">
                        <div class="card-header bg-light d-flex justify-content-between align-items-center">
                            <h6 class="mb-0 fw-semibold text-uppercase fs-12">System Control Activity</h6>
                            <button class="btn btn-sm btn-outline-secondary" onclick="loadOverviewActivities()">
                                <i class="bx bx-refresh fs-14 me-1"></i> Refresh Logs
                            </button>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover table-striped mb-0 align-middle">
                                    <thead class="table-light text-uppercase fs-12">
                                        <tr>
                                            <th>Activity</th>
                                            <th>Module</th>
                                            <th>Performed By</th>
                                            <th>Time</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody id="overview-activity-table-body">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ==================== 2. RULE PRIORITY TAB ==================== -->
                <div class="tab-pane fade" id="rule-priority" role="tabpanel" aria-labelledby="rule-priority-tab">
                    <!-- Info Alert -->
                    <div class="info-box mb-4 d-flex align-items-start gap-3">
                        <i class="bx bx-info-circle fs-3 text-primary mt-1"></i>
                        <div>
                            <strong class="text-dark">Rule Priority</strong> determines which rule will be applied when multiple rules are applicable. Higher priority rules will override lower priority rules and control <strong>commission rates</strong>.
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header bg-light">
                            <h6 class="mb-0 fw-semibold text-uppercase">Priority List</h6>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover table-striped mb-0 align-middle">
                                    <thead class="table-light text-uppercase fs-12">
                                        <tr>
                                            <th style="width: 100px;">Priority Order</th>
                                            <th>Rule Level</th>
                                            <th>Description</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="rule-priority-table-body">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- Example -->
                    <div class="example-box mt-4 d-flex align-items-start gap-3">
                        <i class="bx bx-bulb fs-3 text-warning mt-1"></i>
                        <div>
                            <strong class="text-dark">Example:</strong> If a seller has a <strong>specific rule</strong> and a <strong>category rule</strong>, the system will apply the <strong class="text-success">Seller Specific Rule</strong>.
                            <br><span class="text-muted fs-12 mt-1 d-block">App commission = 20% | Category commission = 15% | Seller special = 10% → ✅ System uses Seller rule (10%)</span>
                        </div>
                    </div>
                </div>

                <!-- ==================== 3. VALIDATION RULES TAB ==================== -->
                <div class="tab-pane fade" id="validation-rules" role="tabpanel" aria-labelledby="validation-rules-tab">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h6 class="fw-semibold text-uppercase mb-0">Validation Configuration</h6>
                        <button class="btn btn-sm btn-primary" onclick="showAddValidationModal()">
                            <i class="bx bx-plus me-1"></i> Add New Rule
                        </button>
                    </div>

                    <div class="card">
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover table-striped mb-0 align-middle">
                                    <thead class="table-light text-uppercase fs-12">
                                        <tr>
                                            <th>Rule Name</th>
                                            <th>Description</th>
                                            <th>Applies To</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="validation-rules-table-body">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ==================== 4. WORKFLOW RULES TAB ==================== -->
                <div class="tab-pane fade" id="workflow-rules" role="tabpanel" aria-labelledby="workflow-rules-tab">
                    <!-- Sub-pills for workflows -->
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <ul class="nav nav-pills nav-pills-custom" id="workflowSubTab" role="tablist">
                            <li class="nav-item"><button class="nav-link active" data-bs-toggle="pill" data-bs-target="#wf-content" type="button" onclick="loadWorkflow('seller')">Seller Workflow</button></li>
                            <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#wf-content" type="button" onclick="loadWorkflow('product')">Product Workflow</button></li>
                            <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#wf-content" type="button" onclick="loadWorkflow('order')">Order Workflow</button></li>
                            <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#wf-content" type="button" onclick="loadWorkflow('refund')">Refund Workflow</button></li>
                            <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#wf-content" type="button" onclick="loadWorkflow('lead')">Lead Workflow</button></li>
                        </ul>
                        <button class="btn btn-sm btn-outline-primary" id="btn-edit-workflow" onclick="editWorkflowCurrent()">
                            <i class="bx bx-edit me-1"></i> Edit Workflow Steps
                        </button>
                    </div>

                    <div class="tab-content" id="workflowSubTabContent">
                        <div class="tab-pane fade show active" id="wf-content" role="tabpanel">
                            <div id="workflow-visualization" class="workflow-container">
                                <!-- Dynamically loaded steps -->
                            </div>

                            <div class="row g-3">
                                <div class="col-md-7">
                                    <div class="card h-100">
                                        <div class="card-header bg-light">
                                            <h6 class="mb-0 fw-semibold text-uppercase fs-12">Workflow Description</h6>
                                        </div>
                                        <div class="card-body">
                                            <p class="text-muted mb-3">This workflow defines the status flow for <strong id="wf-title-display">Seller Management</strong>. Each status transition is controlled by system rules and admin actions.</p>
                                            <ul class="list-unstyled mb-0" id="workflow-description-list">
                                                <!-- Dynamically filled status items -->
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="card h-100">
                                        <div class="card-header bg-light">
                                            <h6 class="mb-0 fw-semibold text-uppercase fs-12">Workflow Settings</h6>
                                        </div>
                                        <div class="card-body" id="workflow-settings-list">
                                            <!-- Dynamically filled switches -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ==================== 5. AUTOMATION RULES TAB ==================== -->
                <div class="tab-pane fade" id="automation-rules" role="tabpanel" aria-labelledby="automation-rules-tab">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h6 class="fw-semibold text-uppercase mb-0">System Automation Triggers</h6>
                        <button class="btn btn-sm btn-primary" onclick="showAddAutomationModal()">
                            <i class="bx bx-plus me-1"></i> Add Automation Rule
                        </button>
                    </div>

                    <div class="card">
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover table-striped mb-0 align-middle">
                                    <thead class="table-light text-uppercase fs-12">
                                        <tr>
                                            <th>Rule Name</th>
                                            <th>Trigger</th>
                                            <th>Action</th>
                                            <th>Status</th>
                                            <th>Last Run</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="automation-rules-table-body">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ==================== 6. ADMIN ROLE MANAGEMENT TAB ==================== -->
                <div class="tab-pane fade" id="role-management" role="tabpanel" aria-labelledby="role-management-tab">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h6 class="fw-semibold text-uppercase mb-0">Admin Role Permissions</h6>
                        <button class="btn btn-sm btn-primary" onclick="showAddRoleModal()">
                            <i class="bx bx-plus me-1"></i> Add New Role
                        </button>
                    </div>

                    <div class="card">
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover table-striped mb-0 align-middle">
                                    <thead class="table-light text-uppercase fs-12">
                                        <tr>
                                            <th>Role Name</th>
                                            <th>Description</th>
                                            <th>Users</th>
                                            <th>Last Login</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="role-management-table-body">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- Access Controls -->
                    <div class="card mt-3">
                        <div class="card-header bg-light">
                            <h6 class="mb-0 fw-semibold text-uppercase fs-12">Access Controls</h6>
                        </div>
                        <div class="card-body">
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <div class="d-flex align-items-center p-3 bg-light rounded">
                                        <i class="bx bx-lock-alt fs-3 text-primary me-3"></i>
                                        <div>
                                            <h6 class="mb-0 fs-13">Module-wise Access</h6>
                                            <small class="text-muted">Control per-module access</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="d-flex align-items-center p-3 bg-light rounded">
                                        <i class="bx bx-shield-alt-2 fs-3 text-success me-3"></i>
                                        <div>
                                            <h6 class="mb-0 fs-13">Action-Level Permissions</h6>
                                            <small class="text-muted">Create / Edit / Delete / View</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="d-flex align-items-center p-3 bg-light rounded">
                                        <i class="bx bx-history fs-3 text-warning me-3"></i>
                                        <div>
                                            <h6 class="mb-0 fs-13">Login History</h6>
                                            <small class="text-muted">IP, Device, Time tracking</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="d-flex align-items-center p-3 bg-light rounded">
                                        <i class="bx bx-error-circle fs-3 text-danger me-3"></i>
                                        <div>
                                            <h6 class="mb-0 fs-13">Failed Login Attempts</h6>
                                            <small class="text-muted">Auto-lock after threshold</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="d-flex align-items-center p-3 bg-light rounded">
                                        <i class="bx bx-timer fs-3 text-info me-3"></i>
                                        <div>
                                            <h6 class="mb-0 fs-13">Session Timeout Control</h6>
                                            <small class="text-muted">Auto-logout after inactivity</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="d-flex align-items-center p-3 bg-light rounded">
                                        <i class="bx bx-log-out-circle fs-3 text-secondary me-3"></i>
                                        <div>
                                            <h6 class="mb-0 fs-13">Force Logout</h6>
                                            <small class="text-muted">Force logout all devices</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>



                <!-- ==================== 8. COMPLIANCE TAB ==================== -->
                <div class="tab-pane fade" id="compliance" role="tabpanel" aria-labelledby="compliance-tab">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <ul class="nav nav-pills nav-pills-custom" id="complianceSubTabs" role="tablist">
                            <li class="nav-item"><a class="nav-link active" data-bs-toggle="pill" href="#policies-content" role="tab">Policies</a></li>
                            <li class="nav-item"><a class="nav-link" data-bs-toggle="pill" href="#agreements-content" role="tab">Agreements</a></li>
                            <li class="nav-item"><a class="nav-link" data-bs-toggle="pill" href="#kyc-verify-content" role="tab">KYC & Verification</a></li>
                            <li class="nav-item"><a class="nav-link" data-bs-toggle="pill" href="#audit-logs-content" role="tab">Audit Logs</a></li>
                        </ul>
                        <button class="btn btn-sm btn-primary" onclick="showAddComplianceModal()">
                            <i class="bx bx-plus me-1"></i> Add Policy
                        </button>
                    </div>

                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="policies-content" role="tabpanel">
                            <div class="card">
                                <div class="card-body p-0">
                                    <div class="table-responsive">
                                        <table class="table table-hover table-striped mb-0 align-middle">
                                            <thead class="table-light text-uppercase fs-12">
                                                <tr>
                                                    <th>Policy Name</th>
                                                    <th>Description</th>
                                                    <th>Category</th>
                                                    <th>Version</th>
                                                    <th>Last Updated</th>
                                                    <th>Status</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody id="compliance-table-body">
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ==================== 9. NOTIFICATION ENGINE TAB ==================== -->
                <div class="tab-pane fade" id="notification-engine" role="tabpanel" aria-labelledby="notification-engine-tab">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <ul class="nav nav-pills nav-pills-custom" id="notificationSubTabs" role="tablist">
                            <li class="nav-item"><a class="nav-link active" data-bs-toggle="pill" href="#email-templates-content" role="tab">Email Templates</a></li>
                            <li class="nav-item"><a class="nav-link" data-bs-toggle="pill" href="#sms-templates-content" role="tab">SMS Templates</a></li>
                            <li class="nav-item"><a class="nav-link" data-bs-toggle="pill" href="#whatsapp-templates-content" role="tab">WhatsApp Templates</a></li>
                            <li class="nav-item"><a class="nav-link" data-bs-toggle="pill" href="#triggers-content" role="tab">Event Triggers</a></li>
                        </ul>
                        <button class="btn btn-sm btn-primary" onclick="showAddTemplateModal()">
                            <i class="bx bx-plus me-1"></i> Add Template
                        </button>
                    </div>

                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="email-templates-content" role="tabpanel">
                            <div class="card">
                                <div class="card-body p-0">
                                    <div class="table-responsive">
                                        <table class="table table-hover table-striped mb-0 align-middle">
                                            <thead class="table-light text-uppercase fs-12">
                                                <tr>
                                                    <th>Template Name</th>
                                                    <th>Type</th>
                                                    <th>Subject / Title</th>
                                                    <th>Status</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody id="notification-table-body">
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

        </div>
    </div>
</div>

<!-- Modal Validation Rule -->
<div class="modal fade" id="validationModal" tabindex="-1" aria-labelledby="validationModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="validationModalLabel">Add Validation Rule</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="validationForm" onsubmit="saveValidation(event)">
                <div class="modal-body">
                    <input type="hidden" id="validation-index">
                    <div class="mb-3">
                        <label for="validation-name" class="form-label">Rule Name</label>
                        <input type="text" class="form-control" id="validation-name" required>
                    </div>
                    <div class="mb-3">
                        <label for="validation-desc" class="form-label">Description</label>
                        <textarea class="form-control" id="validation-desc" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="validation-applies" class="form-label">Applies To</label>
                        <select class="form-select" id="validation-applies" required>
                            <option value="Sellers">Sellers</option>
                            <option value="Products">Products</option>
                            <option value="Orders">Orders</option>
                            <option value="Refunds">Refunds</option>
                            <option value="Leads">Leads</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="validation-status" class="form-label">Status</label>
                        <select class="form-select" id="validation-status" required>
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Rule</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Automation Rule -->
<div class="modal fade" id="automationModal" tabindex="-1" aria-labelledby="automationModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="automationModalLabel">Add Automation Rule</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="automationForm" onsubmit="saveAutomation(event)">
                <div class="modal-body">
                    <input type="hidden" id="automation-index">
                    <div class="mb-3">
                        <label for="automation-name" class="form-label">Rule Name</label>
                        <input type="text" class="form-control" id="automation-name" required>
                    </div>
                    <div class="mb-3">
                        <label for="automation-trigger" class="form-label">Trigger Event</label>
                        <input type="text" class="form-control" id="automation-trigger" required placeholder="e.g. Order Delivered">
                    </div>
                    <div class="mb-3">
                        <label for="automation-action" class="form-label">Action to Take</label>
                        <input type="text" class="form-control" id="automation-action" required placeholder="e.g. Release payout">
                    </div>
                    <div class="mb-3">
                        <label for="automation-status" class="form-label">Status</label>
                        <select class="form-select" id="automation-status" required>
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="automation-last-run" class="form-label">Last Run</label>
                        <input type="text" class="form-control" id="automation-last-run">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Rule</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Role -->
<div class="modal fade" id="roleModal" tabindex="-1" aria-labelledby="roleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="roleModalLabel">Add Admin Role</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="roleForm" onsubmit="saveRole(event)">
                <div class="modal-body">
                    <input type="hidden" id="role-index">
                    <div class="mb-3">
                        <label for="role-name" class="form-label">Role Name</label>
                        <input type="text" class="form-control" id="role-name" required>
                    </div>
                    <div class="mb-3">
                        <label for="role-desc" class="form-label">Description</label>
                        <textarea class="form-control" id="role-desc" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="role-users" class="form-label">Assigned Users</label>
                        <input type="number" class="form-control" id="role-users" min="0" required>
                    </div>
                    <div class="mb-3">
                        <label for="role-status" class="form-label">Status</label>
                        <select class="form-select" id="role-status" required>
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="role-last-login" class="form-label">Last Login</label>
                        <input type="text" class="form-control" id="role-last-login">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Role</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Staff -->
<div class="modal fade" id="staffModal" tabindex="-1" aria-labelledby="staffModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staffModalLabel">Add Staff Member</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="staffForm" onsubmit="saveStaff(event)">
                <div class="modal-body">
                    <input type="hidden" id="staff-index">
                    <div class="mb-3">
                        <label for="staff-id" class="form-label">Staff ID</label>
                        <input type="text" class="form-control" id="staff-id" required placeholder="e.g. EMP006">
                    </div>
                    <div class="mb-3">
                        <label for="staff-name" class="form-label">Name</label>
                        <input type="text" class="form-control" id="staff-name" required>
                    </div>
                    <div class="mb-3">
                        <label for="staff-dept" class="form-label">Department</label>
                        <input type="text" class="form-control" id="staff-dept" required>
                    </div>
                    <div class="mb-3">
                        <label for="staff-designation" class="form-label">Designation</label>
                        <input type="text" class="form-control" id="staff-designation" required>
                    </div>
                    <div class="mb-3">
                        <label for="staff-email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="staff-email" required>
                    </div>
                    <div class="mb-3">
                        <label for="staff-phone" class="form-label">Phone</label>
                        <input type="text" class="form-control" id="staff-phone" required>
                    </div>
                    <div class="mb-3">
                        <label for="staff-status" class="form-label">Status</label>
                        <select class="form-select" id="staff-status" required>
                            <option value="Active">Active</option>
                            <option value="On Leave">On Leave</option>
                            <option value="Inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Staff</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Compliance -->
<div class="modal fade" id="complianceModal" tabindex="-1" aria-labelledby="complianceModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="complianceModalLabel">Add Compliance Policy</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="complianceForm" onsubmit="saveCompliance(event)">
                <div class="modal-body">
                    <input type="hidden" id="compliance-index">
                    <div class="mb-3">
                        <label for="compliance-name" class="form-label">Policy Name</label>
                        <input type="text" class="form-control" id="compliance-name" required>
                    </div>
                    <div class="mb-3">
                        <label for="compliance-desc" class="form-label">Description</label>
                        <textarea class="form-control" id="compliance-desc" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="compliance-category" class="form-label">Category</label>
                        <select class="form-select" id="compliance-category" required>
                            <option value="KYC & Verification">KYC & Verification</option>
                            <option value="Policies">Policies</option>
                            <option value="Agreements">Agreements</option>
                            <option value="Audit Logs">Audit Logs</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="compliance-version" class="form-label">Version</label>
                        <input type="text" class="form-control" id="compliance-version" required placeholder="e.g. v1.0">
                    </div>
                    <div class="mb-3">
                        <label for="compliance-updated" class="form-label">Last Updated</label>
                        <input type="text" class="form-control" id="compliance-updated">
                    </div>
                    <div class="mb-3">
                        <label for="compliance-status" class="form-label">Status</label>
                        <select class="form-select" id="compliance-status" required>
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Policy</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Notification Template -->
<div class="modal fade" id="notificationModal" tabindex="-1" aria-labelledby="notificationModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="notificationModalLabel">Add Notification Template</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="notificationForm" onsubmit="saveNotification(event)">
                <div class="modal-body">
                    <input type="hidden" id="notification-index">
                    <div class="mb-3">
                        <label for="notification-name" class="form-label">Template Name</label>
                        <input type="text" class="form-control" id="notification-name" required>
                    </div>
                    <div class="mb-3">
                        <label for="notification-type" class="form-label">Type</label>
                        <select class="form-select" id="notification-type" required>
                            <option value="Email">Email</option>
                            <option value="SMS">SMS</option>
                            <option value="WhatsApp">WhatsApp</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="notification-subject" class="form-label">Subject / Title</label>
                        <input type="text" class="form-control" id="notification-subject" required>
                    </div>
                    <div class="mb-3">
                        <label for="notification-status" class="form-label">Status</label>
                        <select class="form-select" id="notification-status" required>
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Template</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Workflow Steps Manager -->
<div class="modal fade" id="workflowEditModal" tabindex="-1" aria-labelledby="workflowEditModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="workflowEditModalLabel">Edit Workflow Steps</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="text-muted">Manage status pipeline stages and order.</span>
                    <button class="btn btn-sm btn-primary" onclick="showAddWorkflowStepModal()">
                        <i class="bx bx-plus me-1"></i> Add Step
                    </button>
                </div>
                <div class="table-responsive">
                    <table class="table align-middle">
                        <thead>
                            <tr>
                                <th style="width: 60px;">Order</th>
                                <th>Status Name</th>
                                <th>Description</th>
                                <th>Icon</th>
                                <th>Class</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="workflow-steps-list-body">
                            <!-- Dynamic steps table -->
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal Workflow Step Add/Edit -->
<div class="modal fade" id="workflowStepModal" tabindex="-1" aria-labelledby="workflowStepModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="workflowStepModalLabel">Add Workflow Step</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="workflowStepForm" onsubmit="saveWorkflowStep(event)">
                <div class="modal-body">
                    <input type="hidden" id="wf-step-index">
                    <div class="mb-3">
                        <label for="wf-step-status" class="form-label">Status Name</label>
                        <input type="text" class="form-control" id="wf-step-status" required>
                    </div>
                    <div class="mb-3">
                        <label for="wf-step-desc" class="form-label">Description</label>
                        <input type="text" class="form-control" id="wf-step-desc" required>
                    </div>
                    <div class="mb-3">
                        <label for="wf-step-icon" class="form-label">Boxicon Name</label>
                        <input type="text" class="form-control" id="wf-step-icon" required placeholder="e.g. bx-time, bx-check">
                    </div>
                    <div class="mb-3">
                        <label for="wf-step-color" class="form-label">Color Class</label>
                        <select class="form-select" id="wf-step-color" required>
                            <option value="active">Active (Purple)</option>
                            <option value="completed">Completed (Green)</option>
                            <option value="warning">Warning (Orange)</option>
                            <option value="suspended">Suspended (Red)</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="backToWorkflowEditModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Step</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal View Staff Detail -->
<div class="modal fade" id="staffViewModal" tabindex="-1" aria-labelledby="staffViewModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staffViewModalLabel">Staff Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-borderless">
                    <tr>
                        <th class="text-muted" style="width: 120px;">Staff ID</th>
                        <td id="view-staff-id" class="fw-bold"></td>
                    </tr>
                    <tr>
                        <th class="text-muted">Full Name</th>
                        <td id="view-staff-name" class="fw-semibold"></td>
                    </tr>
                    <tr>
                        <th class="text-muted">Department</th>
                        <td id="view-staff-dept"></td>
                    </tr>
                    <tr>
                        <th class="text-muted">Designation</th>
                        <td id="view-staff-designation"></td>
                    </tr>
                    <tr>
                        <th class="text-muted">Email</th>
                        <td id="view-staff-email"></td>
                    </tr>
                    <tr>
                        <th class="text-muted">Phone</th>
                        <td id="view-staff-phone"></td>
                    </tr>
                    <tr>
                        <th class="text-muted">Status</th>
                        <td><span id="view-staff-status" class="badge"></span></td>
                    </tr>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

@endsection

@section('script')
<script>
    // Master data from controller
    const masterData = @json($settingsData);

    document.addEventListener("DOMContentLoaded", function() {
        // Handle tab change → update breadcrumb
        const tabElList = [].slice.call(document.querySelectorAll('button[data-bs-toggle="tab"]'));
        tabElList.forEach(function (tabEl) {
            tabEl.addEventListener('shown.bs.tab', function (event) {
                const tabTitle = event.target.innerText.replace(/^\d+\.\s+/, '').trim();
                document.getElementById('breadcrumb-active').innerText = tabTitle;
            });
        });

        // Check URL params for tab activation
        const urlParams = new URLSearchParams(window.location.search);
        const tabParam = urlParams.get('tab');
        if (tabParam) {
            const tabButton = document.getElementById(tabParam + '-tab');
            if (tabButton) {
                const bsTab = new bootstrap.Tab(tabButton);
                bsTab.show();
            }
        }

        // Load all sections
        loadOverviewActivities();
        loadRulePriority();
        loadValidationRules();
        loadWorkflow('seller'); // Render default workflow
        loadWorkflowSettings();
        loadAutomationRules();
        loadRoleManagement();
        loadCompliancePolicies();
        loadNotificationTemplates();
        updateOverviewMetrics();
    });

    // Helper to format date
    function getFormattedDate() {
        const d = new Date();
        const months = ["Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar", "Apr", "May"];
        const day = String(d.getDate()).padStart(2, '0');
        const month = months[d.getMonth()];
        const year = d.getFullYear();
        let hours = d.getHours();
        const minutes = String(d.getMinutes()).padStart(2, '0');
        const ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12; // the hour '0' should be '12'
        const strTime = String(hours).padStart(2, '0') + ':' + minutes + ' ' + ampm;
        return `${day} ${month} ${year} ${strTime}`;
    }

    // Add activity log entry dynamically
    function logActivity(activity, moduleName) {
        if (!masterData.activities) {
            masterData.activities = [];
        }
        masterData.activities.unshift({
            activity: activity,
            module: moduleName,
            performed_by: 'Super Admin',
            time: getFormattedDate(),
            status: 'Success'
        });
        // Keep last 15 items
        if (masterData.activities.length > 15) {
            masterData.activities.pop();
        }
        saveSettingAJAX('master_activities', masterData.activities, false); // Save silently
        loadOverviewActivities();
    }

    // ==================== 1. OVERVIEW ====================
    function loadOverviewActivities() {
        const tbody = document.getElementById('overview-activity-table-body');
        tbody.innerHTML = '';
        if (masterData.activities && masterData.activities.length > 0) {
            masterData.activities.forEach(act => {
                tbody.innerHTML += `
                    <tr>
                        <td><span class="fw-semibold text-dark">${act.activity}</span></td>
                        <td><span class="badge bg-light text-secondary border">${act.module}</span></td>
                        <td>${act.performed_by}</td>
                        <td><i class="bx bx-calendar me-1 text-muted"></i>${act.time}</td>
                        <td><span class="badge bg-success-subtle text-success">${act.status}</span></td>
                    </tr>
                `;
            });
        } else {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">No activity logs found.</td></tr>';
        }
    }

    function updateOverviewMetrics() {
        // Rule Engine count: Active Validation rules + Active Automation rules
        const activeRulesCount = (masterData.validation_rules || []).filter(r => r.status === 'Active').length + 
                                 (masterData.automation_rules || []).filter(r => r.status === 'Active').length;
        document.getElementById('metric-rules-count').innerText = activeRulesCount;
        document.getElementById('metric-rules-badge').innerText = `${(masterData.validation_rules || []).filter(r => r.status === 'Active').length} Active Rules`;

        // Roles count
        document.getElementById('metric-roles-count').innerText = (masterData.roles || []).length;

        // Compliance policies
        document.getElementById('metric-compliance-count').innerText = (masterData.compliance || []).length;

        // Notifications count
        document.getElementById('metric-notifications-count').innerText = (masterData.notifications || []).length;
    }

    // ==================== 2. RULE PRIORITY ====================
    function loadRulePriority() {
        const tbody = document.getElementById('rule-priority-table-body');
        tbody.innerHTML = '';
        const colors = ['#6c5ffc', '#10b981', '#3b82f6', '#f59e0b', '#6b7280'];
        (masterData.priorities || []).forEach((rule, idx) => {
            tbody.innerHTML += `
                <tr>
                    <td><span class="priority-badge" style="background:${colors[idx] || '#6b7280'}">${idx + 1}</span></td>
                    <td><span class="fw-semibold text-dark">${rule.level}</span></td>
                    <td class="text-muted">${rule.description}</td>
                    <td>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" role="switch" ${rule.status === 'Active' ? 'checked' : ''} onchange="togglePriority(${idx})">
                        </div>
                    </td>
                    <td>
                        <button class="btn btn-sm btn-icon btn-light text-primary me-1" onclick="movePriority(${idx}, 'up')" ${idx === 0 ? 'disabled' : ''} title="Move Up"><i class="bx bx-up-arrow-alt"></i></button>
                        <button class="btn btn-sm btn-icon btn-light text-primary" onclick="movePriority(${idx}, 'down')" ${idx === masterData.priorities.length - 1 ? 'disabled' : ''} title="Move Down"><i class="bx bx-down-arrow-alt"></i></button>
                    </td>
                </tr>
            `;
        });
    }

    function togglePriority(index) {
        masterData.priorities[index].status = masterData.priorities[index].status === 'Active' ? 'Inactive' : 'Active';
        saveSettingAJAX('master_priorities', masterData.priorities);
        logActivity(`Toggled status of Priority Rule: ${masterData.priorities[index].level}`, 'Rule Priority');
    }

    function movePriority(index, direction) {
        if (direction === 'up' && index > 0) {
            const temp = masterData.priorities[index];
            masterData.priorities[index] = masterData.priorities[index - 1];
            masterData.priorities[index - 1] = temp;
        } else if (direction === 'down' && index < masterData.priorities.length - 1) {
            const temp = masterData.priorities[index];
            masterData.priorities[index] = masterData.priorities[index + 1];
            masterData.priorities[index + 1] = temp;
        }
        saveSettingAJAX('master_priorities', masterData.priorities);
        loadRulePriority();
        logActivity(`Reordered Priority Rule: ${masterData.priorities[direction === 'up' ? index - 1 : index + 1].level}`, 'Rule Priority');
    }

    // ==================== 3. VALIDATION RULES ====================
    function loadValidationRules() {
        const tbody = document.getElementById('validation-rules-table-body');
        tbody.innerHTML = '';
        (masterData.validation_rules || []).forEach((rule, index) => {
            tbody.innerHTML += `
                <tr>
                    <td><span class="fw-semibold text-dark">${rule.name}</span></td>
                    <td class="text-muted">${rule.description}</td>
                    <td><span class="badge bg-light text-dark border">${rule.applies_to}</span></td>
                    <td>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" role="switch" ${rule.status === 'Active' ? 'checked' : ''} onchange="toggleRule('validation', ${index})">
                        </div>
                    </td>
                    <td>
                        <button class="btn btn-sm btn-icon btn-light text-primary me-1" onclick="editItem('validation', ${index})"><i class="bx bx-edit"></i></button>
                        <button class="btn btn-sm btn-icon btn-light text-danger" onclick="deleteItem('validation', ${index})"><i class="bx bx-trash"></i></button>
                    </td>
                </tr>
            `;
        });
    }

    function showAddValidationModal() {
        document.getElementById('validationForm').reset();
        document.getElementById('validation-index').value = '';
        document.getElementById('validationModalLabel').innerText = 'Add Validation Rule';
        new bootstrap.Modal(document.getElementById('validationModal')).show();
    }

    function saveValidation(event) {
        event.preventDefault();
        const indexVal = document.getElementById('validation-index').value;
        const rule = {
            name: document.getElementById('validation-name').value,
            description: document.getElementById('validation-desc').value,
            applies_to: document.getElementById('validation-applies').value,
            status: document.getElementById('validation-status').value
        };

        if (indexVal === '') {
            masterData.validation_rules.push(rule);
            logActivity(`Added Validation Rule: ${rule.name}`, 'Validation Rules');
        } else {
            const idx = parseInt(indexVal);
            masterData.validation_rules[idx] = rule;
            logActivity(`Updated Validation Rule: ${rule.name}`, 'Validation Rules');
        }

        saveSettingAJAX('master_validation_rules', masterData.validation_rules);
        loadValidationRules();
        updateOverviewMetrics();
        bootstrap.Modal.getInstance(document.getElementById('validationModal')).hide();
    }

    // ==================== 4. WORKFLOW RULES ====================
    let currentWorkflow = 'seller';

    function loadWorkflow(type) {
        currentWorkflow = type;
        const viz = document.getElementById('workflow-visualization');
        viz.innerHTML = '';

        if (!masterData.workflows) {
            masterData.workflows = {};
        }
        
        const steps = masterData.workflows[type] || [];
        if (steps.length === 0) {
            viz.innerHTML = '<div class="text-muted text-center py-4 w-100">No steps defined for this workflow. Click Edit Workflow Steps to add.</div>';
            return;
        }

        steps.forEach((step, idx) => {
            const activeClass = step.color || 'active'; // active, completed, warning, suspended
            viz.innerHTML += `
                <div class="workflow-step ${activeClass}">
                    <div class="workflow-circle"><i class="bx ${step.icon || 'bx-right-arrow-alt'} fs-4"></i></div>
                    <h6 class="mt-2 mb-1 fw-bold text-dark fs-13">${step.status}</h6>
                    <p class="text-muted fs-11 px-1 mb-0">${step.description}</p>
                </div>
            `;
            if (idx < steps.length - 1) {
                viz.innerHTML += `<div class="workflow-arrow"><i class="bx bx-right-arrow-alt"></i></div>`;
            }
        });

        // Update display titles
        const titles = {
            'seller': 'Seller Management',
            'product': 'Product Management',
            'order': 'Order Processing',
            'refund': 'Refund Processing',
            'lead': 'Lead Conversion'
        };
        document.getElementById('wf-title-display').innerText = titles[type] || type;

        // Also update checklist items under workflow description
        const descList = document.getElementById('workflow-description-list');
        descList.innerHTML = '';
        (masterData.workflow_settings || []).forEach(setting => {
            const icon = setting.enabled ? 'bx-check-circle text-success' : 'bx-x-circle text-danger';
            descList.innerHTML += `
                <li class="mb-2"><i class="bx ${icon} me-2"></i> ${setting.name}</li>
            `;
        });
    }

    function loadWorkflowSettings() {
        const container = document.getElementById('workflow-settings-list');
        container.innerHTML = '';
        (masterData.workflow_settings || []).forEach((setting, index) => {
            container.innerHTML += `
                <div class="form-check form-switch mb-3">
                    <input class="form-check-input" type="checkbox" id="wf-chk-${index}" ${setting.enabled ? 'checked' : ''} onchange="toggleWorkflowSetting(${index})">
                    <label class="form-check-label" for="wf-chk-${index}">${setting.name}</label>
                </div>
            `;
        });
    }

    function toggleWorkflowSetting(index) {
        masterData.workflow_settings[index].enabled = !masterData.workflow_settings[index].enabled;
        saveSettingAJAX('master_workflow_settings', masterData.workflow_settings);
        loadWorkflow(currentWorkflow);
        logActivity(`Toggled workflow setting: ${masterData.workflow_settings[index].name}`, 'Workflow Engine');
    }

    function editWorkflowCurrent() {
        const modal = new bootstrap.Modal(document.getElementById('workflowEditModal'));
        loadWorkflowStepsManager();
        modal.show();
    }

    function loadWorkflowStepsManager() {
        const tbody = document.getElementById('workflow-steps-list-body');
        tbody.innerHTML = '';
        
        if (!masterData.workflows) masterData.workflows = {};
        const steps = masterData.workflows[currentWorkflow] || [];

        if (steps.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No steps defined. Add a step below.</td></tr>';
            return;
        }

        steps.forEach((step, idx) => {
            tbody.innerHTML += `
                <tr>
                    <td><span class="badge bg-secondary">${idx + 1}</span></td>
                    <td><span class="fw-semibold text-dark">${step.status}</span></td>
                    <td><span class="text-muted fs-12">${step.description}</span></td>
                    <td><code>${step.icon}</code></td>
                    <td><span class="badge bg-${step.color === 'active' ? 'primary' : (step.color === 'completed' ? 'success' : (step.color === 'warning' ? 'warning' : 'danger'))}">${step.color}</span></td>
                    <td>
                        <button class="btn btn-sm btn-icon btn-light text-primary me-1" onclick="showEditWorkflowStepModal(${idx})"><i class="bx bx-edit"></i></button>
                        <button class="btn btn-sm btn-icon btn-light text-danger me-1" onclick="deleteWorkflowStep(${idx})"><i class="bx bx-trash"></i></button>
                        <button class="btn btn-sm btn-icon btn-light text-secondary me-1" onclick="moveWorkflowStep(${idx}, 'up')" ${idx === 0 ? 'disabled' : ''}><i class="bx bx-up-arrow-alt"></i></button>
                        <button class="btn btn-sm btn-icon btn-light text-secondary" onclick="moveWorkflowStep(${idx}, 'down')" ${idx === steps.length - 1 ? 'disabled' : ''}><i class="bx bx-down-arrow-alt"></i></button>
                    </td>
                </tr>
            `;
        });
    }

    function showAddWorkflowStepModal() {
        document.getElementById('workflowStepForm').reset();
        document.getElementById('wf-step-index').value = '';
        document.getElementById('workflowStepModalLabel').innerText = 'Add Workflow Step';
        
        // Hide the main steps manager modal first
        bootstrap.Modal.getInstance(document.getElementById('workflowEditModal')).hide();
        new bootstrap.Modal(document.getElementById('workflowStepModal')).show();
    }

    function showEditWorkflowStepModal(index) {
        const step = masterData.workflows[currentWorkflow][index];
        document.getElementById('wf-step-index').value = index;
        document.getElementById('wf-step-status').value = step.status;
        document.getElementById('wf-step-desc').value = step.description;
        document.getElementById('wf-step-icon').value = step.icon;
        document.getElementById('wf-step-color').value = step.color || 'active';
        document.getElementById('workflowStepModalLabel').innerText = 'Edit Workflow Step';

        // Hide manager modal
        bootstrap.Modal.getInstance(document.getElementById('workflowEditModal')).hide();
        new bootstrap.Modal(document.getElementById('workflowStepModal')).show();
    }

    function backToWorkflowEditModal() {
        bootstrap.Modal.getInstance(document.getElementById('workflowStepModal')).hide();
        const modal = new bootstrap.Modal(document.getElementById('workflowEditModal'));
        loadWorkflowStepsManager();
        modal.show();
    }

    function saveWorkflowStep(event) {
        event.preventDefault();
        const indexVal = document.getElementById('wf-step-index').value;
        const step = {
            status: document.getElementById('wf-step-status').value,
            description: document.getElementById('wf-step-desc').value,
            icon: document.getElementById('wf-step-icon').value,
            color: document.getElementById('wf-step-color').value
        };

        if (!masterData.workflows[currentWorkflow]) {
            masterData.workflows[currentWorkflow] = [];
        }

        if (indexVal === '') {
            masterData.workflows[currentWorkflow].push(step);
            logActivity(`Added workflow step ${step.status} to ${currentWorkflow}`, 'Workflow Engine');
        } else {
            const idx = parseInt(indexVal);
            masterData.workflows[currentWorkflow][idx] = step;
            logActivity(`Updated workflow step ${step.status} in ${currentWorkflow}`, 'Workflow Engine');
        }

        saveSettingAJAX('master_workflows', masterData.workflows);
        loadWorkflow(currentWorkflow);
        
        // Back to manager
        bootstrap.Modal.getInstance(document.getElementById('workflowStepModal')).hide();
        const modal = new bootstrap.Modal(document.getElementById('workflowEditModal'));
        loadWorkflowStepsManager();
        modal.show();
    }

    function deleteWorkflowStep(index) {
        if (confirm('Are you sure you want to delete this workflow stage?')) {
            const stepName = masterData.workflows[currentWorkflow][index].status;
            masterData.workflows[currentWorkflow].splice(index, 1);
            saveSettingAJAX('master_workflows', masterData.workflows);
            loadWorkflow(currentWorkflow);
            loadWorkflowStepsManager();
            logActivity(`Deleted workflow step ${stepName} from ${currentWorkflow}`, 'Workflow Engine');
        }
    }

    function moveWorkflowStep(index, direction) {
        const steps = masterData.workflows[currentWorkflow];
        if (direction === 'up' && index > 0) {
            const temp = steps[index];
            steps[index] = steps[index - 1];
            steps[index - 1] = temp;
        } else if (direction === 'down' && index < steps.length - 1) {
            const temp = steps[index];
            steps[index] = steps[index + 1];
            steps[index + 1] = temp;
        }
        saveSettingAJAX('master_workflows', masterData.workflows);
        loadWorkflow(currentWorkflow);
        loadWorkflowStepsManager();
        logActivity(`Reordered workflow steps in ${currentWorkflow}`, 'Workflow Engine');
    }

    // ==================== 5. AUTOMATION RULES ====================
    function loadAutomationRules() {
        const tbody = document.getElementById('automation-rules-table-body');
        tbody.innerHTML = '';
        (masterData.automation_rules || []).forEach((rule, index) => {
            tbody.innerHTML += `
                <tr>
                    <td><span class="fw-semibold text-dark">${rule.name}</span></td>
                    <td><span class="text-secondary">${rule.trigger}</span></td>
                    <td><code class="text-primary">${rule.action}</code></td>
                    <td>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" role="switch" ${rule.status === 'Active' ? 'checked' : ''} onchange="toggleRule('automation', ${index})">
                        </div>
                    </td>
                    <td><i class="bx bx-time-five me-1 text-muted"></i>${rule.last_run}</td>
                    <td>
                        <button class="btn btn-sm btn-icon btn-light text-primary me-1" onclick="editItem('automation', ${index})"><i class="bx bx-edit"></i></button>
                        <button class="btn btn-sm btn-icon btn-light text-danger" onclick="deleteItem('automation', ${index})"><i class="bx bx-trash"></i></button>
                    </td>
                </tr>
            `;
        });
    }

    function showAddAutomationModal() {
        document.getElementById('automationForm').reset();
        document.getElementById('automation-index').value = '';
        document.getElementById('automation-last-run').value = getFormattedDate();
        document.getElementById('automationModalLabel').innerText = 'Add Automation Rule';
        new bootstrap.Modal(document.getElementById('automationModal')).show();
    }

    function saveAutomation(event) {
        event.preventDefault();
        const indexVal = document.getElementById('automation-index').value;
        const rule = {
            name: document.getElementById('automation-name').value,
            trigger: document.getElementById('automation-trigger').value,
            action: document.getElementById('automation-action').value,
            status: document.getElementById('automation-status').value,
            last_run: document.getElementById('automation-last-run').value || 'Never'
        };

        if (indexVal === '') {
            masterData.automation_rules.push(rule);
            logActivity(`Added Automation Trigger: ${rule.name}`, 'Automation Engine');
        } else {
            const idx = parseInt(indexVal);
            masterData.automation_rules[idx] = rule;
            logActivity(`Updated Automation Trigger: ${rule.name}`, 'Automation Engine');
        }

        saveSettingAJAX('master_automation_rules', masterData.automation_rules);
        loadAutomationRules();
        updateOverviewMetrics();
        bootstrap.Modal.getInstance(document.getElementById('automationModal')).hide();
    }

    // ==================== 6. ROLE MANAGEMENT ====================
    function loadRoleManagement() {
        const tbody = document.getElementById('role-management-table-body');
        tbody.innerHTML = '';
        (masterData.roles || []).forEach((role, index) => {
            tbody.innerHTML += `
                <tr>
                    <td><span class="fw-semibold text-dark">${role.name}</span></td>
                    <td class="text-muted">${role.description}</td>
                    <td><span class="badge bg-info-subtle text-info">${role.users} Users</span></td>
                    <td><i class="bx bx-time-five me-1 text-muted"></i>${role.last_login}</td>
                    <td><span class="badge bg-${role.status === 'Active' ? 'success' : 'danger'}-subtle text-${role.status === 'Active' ? 'success' : 'danger'}">${role.status}</span></td>
                    <td>
                        <button class="btn btn-sm btn-icon btn-light text-primary me-1" onclick="editItem('role', ${index})"><i class="bx bx-edit"></i></button>
                        <button class="btn btn-sm btn-icon btn-light text-danger" onclick="deleteItem('role', ${index})"><i class="bx bx-trash"></i></button>
                    </td>
                </tr>
            `;
        });
    }

    function showAddRoleModal() {
        document.getElementById('roleForm').reset();
        document.getElementById('role-index').value = '';
        document.getElementById('role-last-login').value = getFormattedDate();
        document.getElementById('roleModalLabel').innerText = 'Add Admin Role';
        new bootstrap.Modal(document.getElementById('roleModal')).show();
    }

    function saveRole(event) {
        event.preventDefault();
        const indexVal = document.getElementById('role-index').value;
        const role = {
            name: document.getElementById('role-name').value,
            description: document.getElementById('role-desc').value,
            users: parseInt(document.getElementById('role-users').value) || 0,
            status: document.getElementById('role-status').value,
            last_login: document.getElementById('role-last-login').value || 'Never'
        };

        if (indexVal === '') {
            masterData.roles.push(role);
            logActivity(`Created Admin Role: ${role.name}`, 'Admin Role');
        } else {
            const idx = parseInt(indexVal);
            masterData.roles[idx] = role;
            logActivity(`Updated Admin Role: ${role.name}`, 'Admin Role');
        }

        saveSettingAJAX('master_roles', masterData.roles);
        loadRoleManagement();
        updateOverviewMetrics();
        bootstrap.Modal.getInstance(document.getElementById('roleModal')).hide();
    }

    // ==================== 7. STAFF MANAGEMENT ====================
    function loadStaffDirectory() {
        const tbody = document.getElementById('staff-table-body');
        tbody.innerHTML = '';
        (masterData.staff || []).forEach((s, index) => {
            const statusClass = s.status === 'Active' ? 'success' : (s.status === 'On Leave' ? 'warning' : 'danger');
            tbody.innerHTML += `
                <tr>
                    <td><span class="fw-bold text-primary">${s.id}</span></td>
                    <td><span class="fw-semibold text-dark">${s.name}</span></td>
                    <td>${s.department}</td>
                    <td>${s.designation}</td>
                    <td>${s.email}</td>
                    <td><span class="badge bg-${statusClass}-subtle text-${statusClass}">${s.status}</span></td>
                    <td>
                        <button class="btn btn-sm btn-icon btn-light text-primary me-1" onclick="viewStaff(${index})" title="View Details"><i class="bx bx-show"></i></button>
                        <button class="btn btn-sm btn-icon btn-light text-info me-1" onclick="editItem('staff', ${index})" title="Edit Staff"><i class="bx bx-edit"></i></button>
                        <button class="btn btn-sm btn-icon btn-light text-danger" onclick="deleteItem('staff', ${index})" title="Delete Staff"><i class="bx bx-trash"></i></button>
                    </td>
                </tr>
            `;
        });
    }

    function viewStaff(index) {
        const s = masterData.staff[index];
        document.getElementById('view-staff-id').innerText = s.id;
        document.getElementById('view-staff-name').innerText = s.name;
        document.getElementById('view-staff-dept').innerText = s.department;
        document.getElementById('view-staff-designation').innerText = s.designation;
        document.getElementById('view-staff-email').innerText = s.email;
        document.getElementById('view-staff-phone').innerText = s.phone || 'N/A';
        
        const statusEl = document.getElementById('view-staff-status');
        statusEl.innerText = s.status;
        statusEl.className = 'badge bg-' + (s.status === 'Active' ? 'success' : (s.status === 'On Leave' ? 'warning' : 'danger')) + '-subtle text-' + (s.status === 'Active' ? 'success' : (s.status === 'On Leave' ? 'warning' : 'danger'));

        new bootstrap.Modal(document.getElementById('staffViewModal')).show();
    }

    function showAddStaffModal() {
        document.getElementById('staffForm').reset();
        document.getElementById('staff-index').value = '';
        document.getElementById('staffModalLabel').innerText = 'Add Staff Member';
        new bootstrap.Modal(document.getElementById('staffModal')).show();
    }

    function saveStaff(event) {
        event.preventDefault();
        const indexVal = document.getElementById('staff-index').value;
        const staffMem = {
            id: document.getElementById('staff-id').value,
            name: document.getElementById('staff-name').value,
            department: document.getElementById('staff-dept').value,
            designation: document.getElementById('staff-designation').value,
            email: document.getElementById('staff-email').value,
            phone: document.getElementById('staff-phone').value,
            status: document.getElementById('staff-status').value
        };

        if (indexVal === '') {
            masterData.staff.push(staffMem);
            logActivity(`Added Staff Member: ${staffMem.name}`, 'Staff Management');
        } else {
            const idx = parseInt(indexVal);
            masterData.staff[idx] = staffMem;
            logActivity(`Updated Staff Member: ${staffMem.name}`, 'Staff Management');
        }

        saveSettingAJAX('master_staff', masterData.staff);
        loadStaffDirectory();
        updateOverviewMetrics();
        bootstrap.Modal.getInstance(document.getElementById('staffModal')).hide();
    }

    // ==================== 8. COMPLIANCE ====================
    function loadCompliancePolicies() {
        const tbody = document.getElementById('compliance-table-body');
        tbody.innerHTML = '';
        (masterData.compliance || []).forEach((policy, index) => {
            tbody.innerHTML += `
                <tr>
                    <td><span class="fw-semibold text-dark">${policy.name}</span></td>
                    <td class="text-muted">${policy.description}</td>
                    <td><span class="badge bg-primary-subtle text-primary">${policy.category}</span></td>
                    <td><span class="badge bg-light text-dark border">${policy.version}</span></td>
                    <td><i class="bx bx-calendar me-1 text-muted"></i>${policy.last_updated}</td>
                    <td><span class="badge bg-success-subtle text-success">${policy.status}</span></td>
                    <td>
                        <button class="btn btn-sm btn-icon btn-light text-primary me-1" onclick="editItem('compliance', ${index})"><i class="bx bx-edit"></i></button>
                        <button class="btn btn-sm btn-icon btn-light text-danger" onclick="deleteItem('compliance', ${index})"><i class="bx bx-trash"></i></button>
                    </td>
                </tr>
            `;
        });
    }

    function showAddComplianceModal() {
        document.getElementById('complianceForm').reset();
        document.getElementById('compliance-index').value = '';
        document.getElementById('compliance-updated').value = getFormattedDate().split(' ')[0] + ' ' + getFormattedDate().split(' ')[1] + ' ' + getFormattedDate().split(' ')[2]; // e.g. "11 Jun 2026"
        document.getElementById('complianceModalLabel').innerText = 'Add Compliance Policy';
        new bootstrap.Modal(document.getElementById('complianceModal')).show();
    }

    function saveCompliance(event) {
        event.preventDefault();
        const indexVal = document.getElementById('compliance-index').value;
        const policy = {
            name: document.getElementById('compliance-name').value,
            description: document.getElementById('compliance-desc').value,
            category: document.getElementById('compliance-category').value,
            version: document.getElementById('compliance-version').value,
            last_updated: document.getElementById('compliance-updated').value || 'Today',
            status: document.getElementById('compliance-status').value
        };

        if (indexVal === '') {
            masterData.compliance.push(policy);
            logActivity(`Added Compliance Policy: ${policy.name}`, 'Compliance');
        } else {
            const idx = parseInt(indexVal);
            masterData.compliance[idx] = policy;
            logActivity(`Updated Compliance Policy: ${policy.name}`, 'Compliance');
        }

        saveSettingAJAX('master_compliance', masterData.compliance);
        loadCompliancePolicies();
        updateOverviewMetrics();
        bootstrap.Modal.getInstance(document.getElementById('complianceModal')).hide();
    }

    // ==================== 9. NOTIFICATION ENGINE ====================
    function loadNotificationTemplates() {
        const tbody = document.getElementById('notification-table-body');
        tbody.innerHTML = '';
        (masterData.notifications || []).forEach((notif, index) => {
            const typeColor = notif.type === 'Email' ? 'primary' : (notif.type === 'SMS' ? 'success' : 'info');
            tbody.innerHTML += `
                <tr>
                    <td><span class="fw-semibold text-dark">${notif.name}</span></td>
                    <td><span class="badge bg-${typeColor}-subtle text-${typeColor}">${notif.type}</span></td>
                    <td class="text-muted">${notif.subject}</td>
                    <td>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" role="switch" ${notif.status === 'Active' ? 'checked' : ''} onchange="toggleRule('notification', ${index})">
                        </div>
                    </td>
                    <td>
                        <button class="btn btn-sm btn-icon btn-light text-primary me-1" onclick="editItem('notification', ${index})"><i class="bx bx-edit"></i></button>
                        <button class="btn btn-sm btn-icon btn-light text-danger" onclick="deleteItem('notification', ${index})"><i class="bx bx-trash"></i></button>
                    </td>
                </tr>
            `;
        });
    }

    function showAddTemplateModal() {
        document.getElementById('notificationForm').reset();
        document.getElementById('notification-index').value = '';
        document.getElementById('notificationModalLabel').innerText = 'Add Notification Template';
        new bootstrap.Modal(document.getElementById('notificationModal')).show();
    }

    function saveNotification(event) {
        event.preventDefault();
        const indexVal = document.getElementById('notification-index').value;
        const notif = {
            name: document.getElementById('notification-name').value,
            type: document.getElementById('notification-type').value,
            subject: document.getElementById('notification-subject').value,
            status: document.getElementById('notification-status').value
        };

        if (indexVal === '') {
            masterData.notifications.push(notif);
            logActivity(`Added Notification Template: ${notif.name}`, 'Notification Engine');
        } else {
            const idx = parseInt(indexVal);
            masterData.notifications[idx] = notif;
            logActivity(`Updated Notification Template: ${notif.name}`, 'Notification Engine');
        }

        saveSettingAJAX('master_notifications', masterData.notifications);
        loadNotificationTemplates();
        updateOverviewMetrics();
        bootstrap.Modal.getInstance(document.getElementById('notificationModal')).hide();
    }

    // ==================== EDIT ITEM GENERAL DISPATCHER ====================
    function editItem(type, index) {
        if (type === 'validation') {
            const item = masterData.validation_rules[index];
            document.getElementById('validation-index').value = index;
            document.getElementById('validation-name').value = item.name;
            document.getElementById('validation-desc').value = item.description;
            document.getElementById('validation-applies').value = item.applies_to;
            document.getElementById('validation-status').value = item.status;
            document.getElementById('validationModalLabel').innerText = 'Edit Validation Rule';
            new bootstrap.Modal(document.getElementById('validationModal')).show();
        } 
        else if (type === 'automation') {
            const item = masterData.automation_rules[index];
            document.getElementById('automation-index').value = index;
            document.getElementById('automation-name').value = item.name;
            document.getElementById('automation-trigger').value = item.trigger;
            document.getElementById('automation-action').value = item.action;
            document.getElementById('automation-status').value = item.status;
            document.getElementById('automation-last-run').value = item.last_run || '';
            document.getElementById('automationModalLabel').innerText = 'Edit Automation Rule';
            new bootstrap.Modal(document.getElementById('automationModal')).show();
        } 
        else if (type === 'role') {
            const item = masterData.roles[index];
            document.getElementById('role-index').value = index;
            document.getElementById('role-name').value = item.name;
            document.getElementById('role-desc').value = item.description;
            document.getElementById('role-users').value = item.users;
            document.getElementById('role-status').value = item.status;
            document.getElementById('role-last-login').value = item.last_login || '';
            document.getElementById('roleModalLabel').innerText = 'Edit Admin Role';
            new bootstrap.Modal(document.getElementById('roleModal')).show();
        } 
        else if (type === 'staff') {
            const item = masterData.staff[index];
            document.getElementById('staff-index').value = index;
            document.getElementById('staff-id').value = item.id;
            document.getElementById('staff-name').value = item.name;
            document.getElementById('staff-dept').value = item.department;
            document.getElementById('staff-designation').value = item.designation;
            document.getElementById('staff-email').value = item.email;
            document.getElementById('staff-phone').value = item.phone || '';
            document.getElementById('staff-status').value = item.status;
            document.getElementById('staffModalLabel').innerText = 'Edit Staff Member';
            new bootstrap.Modal(document.getElementById('staffModal')).show();
        } 
        else if (type === 'compliance') {
            const item = masterData.compliance[index];
            document.getElementById('compliance-index').value = index;
            document.getElementById('compliance-name').value = item.name;
            document.getElementById('compliance-desc').value = item.description;
            document.getElementById('compliance-category').value = item.category;
            document.getElementById('compliance-version').value = item.version;
            document.getElementById('compliance-updated').value = item.last_updated || '';
            document.getElementById('compliance-status').value = item.status;
            document.getElementById('complianceModalLabel').innerText = 'Edit Compliance Policy';
            new bootstrap.Modal(document.getElementById('complianceModal')).show();
        } 
        else if (type === 'notification') {
            const item = masterData.notifications[index];
            document.getElementById('notification-index').value = index;
            document.getElementById('notification-name').value = item.name;
            document.getElementById('notification-type').value = item.type;
            document.getElementById('notification-subject').value = item.subject;
            document.getElementById('notification-status').value = item.status;
            document.getElementById('notificationModalLabel').innerText = 'Edit Notification Template';
            new bootstrap.Modal(document.getElementById('notificationModal')).show();
        }
    }

    // ==================== DELETE ITEM GENERAL DISPATCHER ====================
    function deleteItem(type, index) {
        let settingName = '';
        let list = [];
        let itemName = '';

        if (type === 'validation') {
            settingName = 'master_validation_rules';
            list = masterData.validation_rules;
            itemName = list[index].name;
        } else if (type === 'automation') {
            settingName = 'master_automation_rules';
            list = masterData.automation_rules;
            itemName = list[index].name;
        } else if (type === 'role') {
            settingName = 'master_roles';
            list = masterData.roles;
            itemName = list[index].name;
        } else if (type === 'staff') {
            settingName = 'master_staff';
            list = masterData.staff;
            itemName = list[index].name;
        } else if (type === 'compliance') {
            settingName = 'master_compliance';
            list = masterData.compliance;
            itemName = list[index].name;
        } else if (type === 'notification') {
            settingName = 'master_notifications';
            list = masterData.notifications;
            itemName = list[index].name;
        }

        if (confirm(`Are you sure you want to delete "${itemName}"?`)) {
            list.splice(index, 1);
            saveSettingAJAX(settingName, list);

            if (type === 'validation') loadValidationRules();
            else if (type === 'automation') loadAutomationRules();
            else if (type === 'role') loadRoleManagement();
            else if (type === 'staff') loadStaffDirectory();
            else if (type === 'compliance') loadCompliancePolicies();
            else if (type === 'notification') loadNotificationTemplates();

            updateOverviewMetrics();
            logActivity(`Deleted ${type} item: ${itemName}`, `${type.charAt(0).toUpperCase() + type.slice(1)} Module`);
        }
    }

    // ==================== TOGGLE & SAVE ====================
    function toggleRule(type, index) {
        let settingName = '';
        let list = [];

        if (type === 'validation') {
            settingName = 'master_validation_rules';
            list = masterData.validation_rules;
            list[index].status = list[index].status === 'Active' ? 'Inactive' : 'Active';
            loadValidationRules();
            logActivity(`Toggled Validation Rule status: ${list[index].name}`, 'Validation Rules');
        } else if (type === 'automation') {
            settingName = 'master_automation_rules';
            list = masterData.automation_rules;
            list[index].status = list[index].status === 'Active' ? 'Inactive' : 'Active';
            loadAutomationRules();
            logActivity(`Toggled Automation Rule status: ${list[index].name}`, 'Automation Rules');
        } else if (type === 'notification') {
            settingName = 'master_notifications';
            list = masterData.notifications;
            list[index].status = list[index].status === 'Active' ? 'Inactive' : 'Active';
            loadNotificationTemplates();
            logActivity(`Toggled Notification template status: ${list[index].name}`, 'Notification Engine');
        }

        saveSettingAJAX(settingName, list);
        updateOverviewMetrics();
    }

    function toggleWorkflowSetting(index) {
        masterData.workflow_settings[index].enabled = !masterData.workflow_settings[index].enabled;
        saveSettingAJAX('master_workflow_settings', masterData.workflow_settings);
        loadWorkflow(currentWorkflow);
        logActivity(`Toggled workflow control: ${masterData.workflow_settings[index].name}`, 'Workflow Engine');
    }

    function saveSettingAJAX(key, value, showToastFlag = true) {
        fetch('{{ route("admin.settings.save_master_config") }}', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            },
            body: JSON.stringify({ key: key, value: JSON.stringify(value) })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                if (showToastFlag) showToast('Setting saved successfully!', 'success');
            } else {
                if (showToastFlag) showToast('Failed to save: ' + data.message, 'danger');
            }
        })
        .catch(err => {
            console.error('Error:', err);
            if (showToastFlag) showToast('Network error. Please try again.', 'danger');
        });
    }

    // Toast notification
    function showToast(message, type = 'success') {
        const toastId = 'toast-' + Date.now();
        const toastHtml = `
            <div id="${toastId}" class="toast align-items-center text-bg-${type} border-0 show position-fixed" role="alert" style="top: 20px; right: 20px; z-index: 9999;">
                <div class="d-flex">
                    <div class="toast-body">${message}</div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                </div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', toastHtml);
        setTimeout(() => {
            const el = document.getElementById(toastId);
            if (el) el.remove();
        }, 3000);
    }
</script>
@endsection
