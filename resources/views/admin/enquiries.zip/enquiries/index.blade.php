@extends('layouts.vertical', ['title' => 'Enquiry Management'])

@section('css')
<link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
<style>
    .metric-card {
        border-radius: 12px;
        transition: all 0.3s ease;
        border: none;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.03);
    }
    .metric-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 20px rgba(0, 67, 146, 0.1);
    }
    .metric-icon-box {
        width: 48px;
        height: 48px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
    }
    .badge-premium {
        padding: 5px 12px;
        border-radius: 30px;
        font-weight: 550;
        font-size: 11px;
        letter-spacing: 0.3px;
    }
    .table-responsive {
        border-radius: 10px;
        overflow: hidden;
    }
</style>
@endsection

@section('content')
<div class="container-fluid">
    <!-- Header -->
    <div class="row align-items-center mb-4">
        <div class="col-sm-6">
            <h4 class="mb-sm-0 text-dark fw-bold">Enquiry Management</h4>
        </div>
        <div class="col-sm-6 text-sm-end">
            <a href="{{ route('admin.enquiry.export') }}" class="btn btn-outline-success px-4 py-2">
                <i class="bx bx-download me-1"></i> Export CSV
            </a>
        </div>
    </div>

    <!-- Alert Notifications -->
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm" role="alert">
            <i class="bx bx-check-circle me-2 fs-5 align-middle"></i>
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    <!-- Statistics Overview -->
    <div class="row g-3 mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="card metric-card">
                <div class="card-body d-flex align-items-center">
                    <div class="metric-icon-box bg-primary bg-opacity-10 text-primary me-3">
                        <i class="bx bx-envelope"></i>
                    </div>
                    <div>
                        <h6 class="text-muted text-uppercase mb-1 fs-11">Total Enquiries</h6>
                        <h3 class="mb-0 fw-bold">{{ $enquiries->total() }}</h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card metric-card">
                <div class="card-body d-flex align-items-center">
                    <div class="metric-icon-box bg-success bg-opacity-10 text-success me-3">
                        <i class="bx bx-check-double"></i>
                    </div>
                    <div>
                        <h6 class="text-muted text-uppercase mb-1 fs-11">Converted</h6>
                        <h3 class="mb-0 fw-bold text-success">{{ \App\Models\Enquiry::where('status', 'converted')->count() }}</h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card metric-card">
                <div class="card-body d-flex align-items-center">
                    <div class="metric-icon-box bg-warning bg-opacity-10 text-warning me-3">
                        <i class="bx bx-time"></i>
                    </div>
                    <div>
                        <h6 class="text-muted text-uppercase mb-1 fs-11">New / Pending</h6>
                        <h3 class="mb-0 fw-bold text-warning">{{ \App\Models\Enquiry::where('status', 'new')->count() }}</h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card metric-card">
                <div class="card-body d-flex align-items-center">
                    <div class="metric-icon-box bg-danger bg-opacity-10 text-danger me-3">
                        <i class="bx bx-x-circle"></i>
                    </div>
                    <div>
                        <h6 class="text-muted text-uppercase mb-1 fs-11">Lost</h6>
                        <h3 class="mb-0 fw-bold text-danger">{{ \App\Models\Enquiry::where('status', 'lost')->count() }}</h3>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filter Section Card -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" action="{{ route('admin.enquiry.index') }}">
                <div class="row g-2 align-items-center">
                    <div class="col-md-3">
                        <div class="input-group">
                            <span class="input-group-text bg-white border-end-0"><i class="bx bx-search text-muted"></i></span>
                            <input type="text" name="search" class="form-control border-start-0 ps-0" placeholder="Search name, email, phone..." value="{{ request('search') }}">
                        </div>
                    </div>
                    <div class="col-md-2">
                        <select name="source" class="form-select">
                            <option value="">All Sources</option>
                            <option value="website" {{ request('source') == 'website' ? 'selected' : '' }}>Website</option>
                            <option value="facebook" {{ request('source') == 'facebook' ? 'selected' : '' }}>Facebook</option>
                            <option value="instagram" {{ request('source') == 'instagram' ? 'selected' : '' }}>Instagram</option>
                            <option value="google_ads" {{ request('source') == 'google_ads' ? 'selected' : '' }}>Google Ads</option>
                            <option value="whatsapp" {{ request('source') == 'whatsapp' ? 'selected' : '' }}>WhatsApp</option>
                            <option value="manual" {{ request('source') == 'manual' ? 'selected' : '' }}>Manual</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select name="status" class="form-select">
                            <option value="">All Statuses</option>
                            <option value="new" {{ request('status') == 'new' ? 'selected' : '' }}>New</option>
                            <option value="contacted" {{ request('status') == 'contacted' ? 'selected' : '' }}>Contacted</option>
                            <option value="quoted" {{ request('status') == 'quoted' ? 'selected' : '' }}>Quoted</option>
                            <option value="converted" {{ request('status') == 'converted' ? 'selected' : '' }}>Converted</option>
                            <option value="closed" {{ request('status') == 'closed' ? 'selected' : '' }}>Closed</option>
                            <option value="lost" {{ request('status') == 'lost' ? 'selected' : '' }}>Lost</option>
                        </select>
                    </div>
                    <div class="col-md-3 d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-50">Filter</button>
                        <a href="{{ route('admin.enquiry.index') }}" class="btn btn-light w-50">Reset</a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Enquiries Table List -->
    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white border-bottom py-3">
            <h5 class="mb-0 fw-semibold text-dark">All Enquiries</h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light text-uppercase fs-11 text-muted">
                        <tr>
                            <th class="ps-4">Enquiry No</th>
                            <th>Customer</th>
                            <th>Product / Service</th>
                            <th>Source</th>
                            <th>Assigned To</th>
                            <th>Status</th>
                            <th>Follow-up</th>
                            <th class="pe-4 text-end">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($enquiries as $enq)
                        <tr>
                            <td class="ps-4">
                                <span class="fw-bold text-dark">#{{ $enq->enquiry_no ?? 'ENQ-'.$enq->id }}</span>
                            </td>
                            <td>
                                <span class="fw-semibold text-dark d-block">{{ $enq->user_name ?? 'N/A' }}</span>
                                <small class="text-muted">{{ $enq->user_email }}</small>
                            </td>
                            <td>
                                <span class="text-dark">{{ Str::limit($enq->product_service, 25) ?? 'N/A' }}</span>
                            </td>
                            <td>
                                @php
                                    $srcColors = [
                                        'website' => 'primary', 'facebook' => 'info', 'instagram' => 'danger',
                                        'google_ads' => 'warning', 'whatsapp' => 'success', 'manual' => 'secondary'
                                    ];
                                    $srcColor = $srcColors[$enq->source] ?? 'secondary';
                                @endphp
                                <span class="badge bg-soft-{{ $srcColor }} text-{{ $srcColor }} badge-premium">{{ ucfirst($enq->source ?? 'N/A') }}</span>
                            </td>
                            <td>
                                @if($enq->tags)
                                    <span class="text-dark"><i class="bx bx-user-circle me-1"></i>{{ $enq->tags }}</span>
                                @else
                                    <span class="text-danger fw-semibold"><i class="bx bx-user-plus me-1"></i>Unassigned</span>
                                @endif
                            </td>
                            <td>
                                @if($enq->status == 'new')
                                    <span class="badge bg-soft-warning text-warning badge-premium">New</span>
                                @elseif($enq->status == 'contacted')
                                    <span class="badge bg-soft-info text-info badge-premium">Contacted</span>
                                @elseif($enq->status == 'quoted')
                                    <span class="badge bg-soft-primary text-primary badge-premium">Quoted</span>
                                @elseif($enq->status == 'converted')
                                    <span class="badge bg-soft-success text-success badge-premium">Converted</span>
                                @elseif($enq->status == 'closed')
                                    <span class="badge bg-secondary badge-premium">Closed</span>
                                @elseif($enq->status == 'lost')
                                    <span class="badge bg-soft-danger text-danger badge-premium">Lost</span>
                                @else
                                    <span class="badge bg-light text-dark badge-premium">{{ ucfirst($enq->status ?? 'N/A') }}</span>
                                @endif
                            </td>
                            <td>
                                @if($enq->next_followup_date)
                                    <small class="text-muted">{{ \Carbon\Carbon::parse($enq->next_followup_date)->format('d M Y') }}</small>
                                @else
                                    <small class="text-muted">—</small>
                                @endif
                            </td>
                            <td class="pe-4 text-end">
                                <button class="btn btn-outline-primary btn-sm px-3 viewEnquiryBtn" data-id="{{ $enq->id }}">
                                    <i class="bx bx-show-alt me-1"></i> View
                                </button>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="8" class="text-center py-4 text-muted">No Enquiries Found</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            <div class="px-4 py-3 border-top">
                {{ $enquiries->links() }}
            </div>
        </div>
    </div>
</div>

<!-- ==================== MODAL: Enquiry Details & Action Sheet ==================== -->
<div class="modal fade" id="detailsEnquiryModal" tabindex="-1" aria-labelledby="detailsEnquiryModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-primary text-white border-0 py-3">
                <h5 class="modal-title fw-bold" id="detailsEnquiryModalLabel">Enquiry Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4">
                <div class="row">
                    <!-- Left Column: Details -->
                    <div class="col-lg-6 border-end">
                        <div class="d-flex align-items-center mb-3">
                            <span class="fs-6 fw-bold text-dark me-2">Enquiry: <span id="lbl_enq_no"></span></span>
                            <span class="badge" id="lbl_enq_status"></span>
                        </div>

                        <table class="table table-bordered align-middle mb-4">
                            <tr>
                                <th class="bg-light text-muted w-40">Customer Name</th>
                                <td id="lbl_enq_name" class="fw-semibold"></td>
                            </tr>
                            <tr>
                                <th class="bg-light text-muted">Email</th>
                                <td id="lbl_enq_email"></td>
                            </tr>
                            <tr>
                                <th class="bg-light text-muted">Mobile</th>
                                <td id="lbl_enq_mobile"></td>
                            </tr>
                            <tr>
                                <th class="bg-light text-muted">Source</th>
                                <td id="lbl_enq_source"></td>
                            </tr>
                            <tr>
                                <th class="bg-light text-muted">Product / Service</th>
                                <td id="lbl_enq_product"></td>
                            </tr>
                            <tr>
                                <th class="bg-light text-muted">Quantity</th>
                                <td id="lbl_enq_qty"></td>
                            </tr>
                            <tr>
                                <th class="bg-light text-muted">Category</th>
                                <td id="lbl_enq_category"></td>
                            </tr>
                            <tr>
                                <th class="bg-light text-muted">Location</th>
                                <td id="lbl_enq_location"></td>
                            </tr>
                            <tr>
                                <th class="bg-light text-muted">Message</th>
                                <td id="lbl_enq_message"></td>
                            </tr>
                            <tr>
                                <th class="bg-light text-muted">Created</th>
                                <td id="lbl_enq_created"></td>
                            </tr>
                            <tr>
                                <th class="bg-light text-muted">Follow-up Note</th>
                                <td id="lbl_enq_followup_note"></td>
                            </tr>
                        </table>
                    </div>

                    <!-- Right Column: Actions -->
                    <div class="col-lg-6">
                        <h6 class="fw-bold text-dark mb-3"><i class="bx bx-cog me-1 text-primary"></i>Actions Panel</h6>
                        <input type="hidden" id="enq_action_id">

                        <!-- Assign to Team Member -->
                        <div class="card p-3 border-0 bg-light mb-3">
                            <small class="fw-semibold text-dark mb-2 d-block">Assign Team / Agent</small>
                            <form id="frm_assign_enquiry">
                                @csrf
                                <div class="input-group">
                                    <select name="assigned_to" class="form-select form-select-sm" required id="select_enq_agent">
                                        <option value="">Select Agent</option>
                                        @foreach($staffMembers as $staff)
                                            <option value="{{ $staff->name }}">{{ $staff->name }} ({{ ucfirst($staff->type) }})</option>
                                        @endforeach
                                    </select>
                                    <button type="submit" class="btn btn-primary btn-sm">Assign</button>
                                </div>
                            </form>
                        </div>

                        <!-- Change Status -->
                        <div class="card p-3 border-0 bg-light mb-3">
                            <small class="fw-semibold text-dark mb-2 d-block">Update Status</small>
                            <form id="frm_status_enquiry">
                                @csrf
                                <div class="input-group">
                                    <select name="status" class="form-select form-select-sm" required id="select_enq_status">
                                        <option value="new">New</option>
                                        <option value="contacted">Contacted</option>
                                        <option value="quoted">Quoted</option>
                                        <option value="converted">Converted</option>
                                        <option value="closed">Closed</option>
                                        <option value="lost">Lost</option>
                                    </select>
                                    <button type="submit" class="btn btn-success btn-sm">Update</button>
                                </div>
                            </form>
                        </div>

                        <!-- Follow-up Info -->
                        <div class="card p-3 border-0 bg-light mb-3">
                            <small class="fw-semibold text-dark mb-2 d-block">Follow-up Schedule</small>
                            <div class="row g-2">
                                <div class="col-6">
                                    <small class="text-muted d-block">Next Follow-up Date</small>
                                    <strong class="text-dark fs-13" id="lbl_followup_date">—</strong>
                                </div>
                                <div class="col-6">
                                    <small class="text-muted d-block">Follow-up Count</small>
                                    <strong class="text-dark fs-13" id="lbl_followup_count">0</strong>
                                </div>
                            </div>
                        </div>

                        <!-- Seller Info -->
                        <div class="card p-3 border-0 bg-light">
                            <small class="fw-semibold text-dark mb-2 d-block">Linked Seller</small>
                            <div id="lbl_seller_info" class="text-muted">No seller linked</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@section('script')
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    // AJAX: View Enquiry Details modal
    $(document).on("click", ".viewEnquiryBtn", function() {
        let id = $(this).data("id");
        $('#enq_action_id').val(id);

        $.get("{{ route('admin.enquiry.index') }}/get/" + id, function(res) {
            if (res.success) {
                let enq = res.enquiry;

                $('#lbl_enq_no').text('#' + (enq.enquiry_no || 'ENQ-' + enq.id));

                // Status badge
                let statusMap = {
                    'new': 'bg-soft-warning text-warning',
                    'contacted': 'bg-soft-info text-info',
                    'quoted': 'bg-soft-primary text-primary',
                    'converted': 'bg-soft-success text-success',
                    'closed': 'bg-secondary text-white',
                    'lost': 'bg-soft-danger text-danger'
                };
                let statusClass = statusMap[enq.status] || 'bg-light text-dark';
                $('#lbl_enq_status').attr('class', 'badge ' + statusClass).text((enq.status || 'N/A').toUpperCase());

                // Set current status in dropdown
                $('#select_enq_status').val(enq.status);

                // Details
                $('#lbl_enq_name').text(enq.user_name || 'N/A');
                $('#lbl_enq_email').text(enq.user_email || 'N/A');
                $('#lbl_enq_mobile').text(enq.user_mobile || 'N/A');
                $('#lbl_enq_source').text(enq.source ? enq.source.charAt(0).toUpperCase() + enq.source.slice(1) : 'N/A');
                $('#lbl_enq_product').text(enq.product_service || 'N/A');
                $('#lbl_enq_qty').text(enq.quantity || 'N/A');
                $('#lbl_enq_category').text((enq.category || '') + (enq.subcategory ? ' → ' + enq.subcategory : ''));
                $('#lbl_enq_location').text((enq.state || '') + (enq.country ? ', ' + enq.country : ''));
                $('#lbl_enq_message').text(enq.message || '—');
                $('#lbl_enq_created').text(enq.formatted_date);
                $('#lbl_enq_followup_note').text(enq.followup_note || '—');
                $('#lbl_followup_date').text(enq.next_followup_date || '—');
                $('#lbl_followup_count').text(enq.followup_count || '0');

                // Assigned agent
                if (enq.tags) {
                    $('#select_enq_agent').val(enq.tags);
                }

                // Seller info
                if (res.seller) {
                    $('#lbl_seller_info').html('<strong>' + res.seller.name + '</strong><br><small class="text-muted">' + (res.seller.email || '') + '</small>');
                } else {
                    $('#lbl_seller_info').text('No seller linked');
                }

                // Show modal
                $('#detailsEnquiryModal').modal('show');
            } else {
                Swal.fire('Error', 'Unable to retrieve enquiry details.', 'error');
            }
        });
    });

    // Form: Assign Agent
    $('#frm_assign_enquiry').on('submit', function(e) {
        e.preventDefault();
        let id = $('#enq_action_id').val();

        $.post("{{ route('admin.enquiry.index') }}/" + id + "/assign", $(this).serialize(), function(res) {
            if (res.success) {
                Swal.fire('Assigned', res.message, 'success').then(() => {
                    location.reload();
                });
            } else {
                Swal.fire('Error', 'Unable to assign agent.', 'error');
            }
        }).fail(function(xhr) {
            Swal.fire('Error', 'Server error: ' + (xhr.responseJSON?.message || 'Something went wrong'), 'error');
        });
    });

    // Form: Update Status
    $('#frm_status_enquiry').on('submit', function(e) {
        e.preventDefault();
        let id = $('#enq_action_id').val();

        $.post("{{ route('admin.enquiry.index') }}/" + id + "/update-status", $(this).serialize(), function(res) {
            if (res.success) {
                Swal.fire('Updated', res.message, 'success').then(() => {
                    location.reload();
                });
            } else {
                Swal.fire('Error', 'Unable to update status.', 'error');
            }
        }).fail(function(xhr) {
            Swal.fire('Error', 'Server error: ' + (xhr.responseJSON?.message || 'Something went wrong'), 'error');
        });
    });
</script>
@endsection
